set -e

curl -L https://apt.procurs.us/bootstraps/1800/bootstrap-iphoneos-arm64.tar.zst --output bootstrap_1800.tar.zst
curl -L https://apt.procurs.us/bootstraps/1900/bootstrap-iphoneos-arm64.tar.zst --output bootstrap_1900.tar.zst
