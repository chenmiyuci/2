#import <Foundation/Foundation.h>
int resign_file(NSString *filePath, bool preserveMetadata);