#import <Foundation/Foundation.h>

int carbonCopy(NSString *sourcePath, NSString *targetPath);