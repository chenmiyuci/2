#ifndef KALLOC_PT_H
#define KALLOC_PT_H

void libjailbreak_kalloc_pt_init(void);

#endif