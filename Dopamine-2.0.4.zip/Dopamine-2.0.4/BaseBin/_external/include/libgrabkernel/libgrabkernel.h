//
//  libgrabkernel.h
//  libgrabkernel
//
//  Created by tihmstar on 31.01.19.
//  Copyright © 2019 tihmstar. All rights reserved.
//

#ifndef libgrabkernel_h
#define libgrabkernel_h

#include <stdio.h>

const char* libgrabkernel_version(void);
int grabkernel(char *downloadPath, int isResearchKernel);


#endif /* libgrabkernel_h */
