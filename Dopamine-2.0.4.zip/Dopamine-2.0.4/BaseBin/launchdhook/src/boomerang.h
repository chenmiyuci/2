int boomerang_recoverPrimitives(bool firstRetrieval, bool shouldEndBoomerang);
void boomerang_stashPrimitives(void);